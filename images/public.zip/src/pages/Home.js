import React from "react";
import Card from "../components/Card";
import { FaRegHandshake } from "react-icons/fa6";
import { MdTableBar } from "react-icons/md";
import { MdOutlineChair } from "react-icons/md";
import { RiUserVoiceLine } from "react-icons/ri";
import { FaPlay } from "react-icons/fa";
import CardBus from "../components/CardBus";
import img1 from "../assets/gallery-1.jpg.webp";
import img2 from "../assets/gallery-2.jpg.webp";
import img3 from "../assets/gallery-3.jpg.webp";
import img4 from "../assets/gallery-4.jpg.webp";
import img5 from "../assets/gallery-5.jpg.webp";
import img6 from "../assets/gallery-6.jpg.webp";
import Work from "../components/Work";

import ImageSlider from "../components/Slider";
import { FaCalculator } from "react-icons/fa";
import { IoSettings } from "react-icons/io5";
import { FaPeopleCarryBox } from "react-icons/fa6";
import BlogCard from "../components/BlogCard";

import Navbar from "../components/Navbar";

export default function Home() {
  const slides = [
    {
      image: { img1 },
      text: "Slide 1 Text",
    },
    {
      image: { img2 },
      text: "Slide 2 Text",
    },
    {
      image: { img3 },
      text: "Slide 3 Text",
    },
  ];
  return (
    <>
      <div className="bg-hero">
        <Navbar />
        <div className="bg-img-hero"></div>
        <div className="container mt-5">
          <div className="row pt-4">
            <div className="col top-padding z-3">
              <p className="mb-0 lh-sm fs-1 font">Best Design of </p>
              <p className="fw-bolder f-size mb-2 lh-sm mt-0">
                Furniture Collections
              </p>
              <p className="w-lg-50 lh-sm">
                A small river named Duden flows by their place and supplies it
                with the necessary regelialia.
              </p>
              <button className="btn btn-dis bg-white px-4 py-3 fs-6 mt-2 shadow border rounded-5">
                DISCOVER
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Cards Section */}
      <div className="container-fluid">
        <div className="row py-2 g-2">
          <div className="col-md-3 col-sm-12">
            <div className="bg-1 p-5 w-100 h-100">
              <Card
                icon={<FaRegHandshake />}
                title="Amazing Deals"
                para="Far far away, behind the word mountains, far from the countries Vokalia."
              />
            </div>
          </div>
          <div className="col-md-3 col-sm-12">
            <div className="bg-2 p-5 w-100 h-100">
              <Card
                icon={<MdTableBar />}
                title="Amazing Deals"
                para="Far far away, behind the word mountains, far from the countries Vokalia."
              />
            </div>
          </div>
          <div className="col-md-3 col-sm-12">
            <div className="bg-3 p-5 w-100 h-100">
              <Card
                icon={<MdOutlineChair />}
                title="Amazing Deals"
                para="Far far away, behind the word mountains, far from the countries Vokalia."
              />
            </div>
          </div>
          <div className="col-md-3 col-sm-12">
            <div className="bg-4 p-5 w-100 h-100">
              <Card
                icon={<RiUserVoiceLine />}
                title="Amazing Deals"
                para="Far far away, behind the word mountains, far from the countries Vokalia."
              />
            </div>
          </div>
        </div>
      </div>
      {/* About Furnish */}
      <div id="bg-about" className="container-fluid">
        <div className="row">
          <div className="col offset-md-5 offset-lg-6 mt-5">
            <div className="p-2 mt-5 pt-5">
              <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                ABOUT FURNISH
              </p>
              <p className="f-size mb-4 lh-sm fw-medium">
                Quality Makes the Belief for Customers
              </p>
              <p className="text-secondary mb-5 fs-6">
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts. Separated
                they live in Bookmarksgrove right at the coast of the Semantics,
                a large language ocean.
              </p>
              <div className="d-flex align-items-center w-50">
                <span className="btn-bg text-center">
                  <FaPlay className="mt-4 ms-1 text-white" />
                </span>
                <button className="btn btn-color fw-bold">Watch Video</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Furniture Collection */}
      <div className="container mt-5">
        <div className="row mt-5">
          <div className="col pt-5">
            <div className="text-center mt-5">
              <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                OUR FINISH PROJECTS
              </p>
              <p className="f-size mb-4 lh-sm fw-medium">
                Furniture Collection
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid mt-5 mb-0">
        <div className="row mt-5 g-2 py-2">
          <div className="col-md-3 col-sm-12">
            <CardBus img={img1} />
          </div>
          <div className="col-md-3 col-sm-12">
            <CardBus img={img2} />
          </div>
          <div className="col-md-6 col-sm-12">
            <CardBus img={img3} />
          </div>
          <div className="col-md-5 col-sm-12">
            <CardBus img={img4} />
          </div>
          <div className="col-md-3 col-sm-12">
            <CardBus img={img5} />
          </div>
          <div className="col-md-4 col-sm-12">
            <CardBus img={img6} />
          </div>
        </div>
      </div>

      {/* Technical Status */}

      <div className="tech-state container-fluid">
        <div className="container pt-5">
          <div className="row">
            <div className="col">
              <div className="text-center mt-5">
                <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                  GREAT REVIEWS FOR OUR SERVICES
                </p>
                <p className="f-size mb-4 lh-sm fw-medium">
                  Technical Statistics
                </p>
              </div>
            </div>
          </div>
          <div className="row text-center mt-5 pb-5">
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-2 mb-0 fw-bold">20</p>
                <p className="fs-6 opacity-50 text-secondary fw-bold">
                  YEAR OF EXPERIENCED
                </p>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-2 mb-0 fw-bold">10,200</p>
                <p className="fs-6 opacity-50 text-secondary fw-bold">
                  SATISFIED CUSTOMERS
                </p>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-2 mb-0 fw-bold">9,850</p>
                <p className="fs-6 opacity-50 text-secondary fw-bold">
                  PROJECT COMPLETED
                </p>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-2 mb-0 fw-bold">20</p>
                <p className="fs-6 opacity-50 text-secondary fw-bold">
                  GET AWARDS
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Happy Customers */}

      <div className="container-fluid body-color pt-5">
        <div className="container">
          <div className="row">
            <div className="col">
              <div className="text-center mt-5">
                <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                  TESTIMONIAL
                </p>
                <p className="f-size mb-4 fw-medium">Happy Customers</p>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col">
              <ImageSlider slides={slides} />
            </div>
          </div>
        </div>
      </div>

      {/* Works Section */}

      <div className="container-fluid body-color pt-5 pb-5">
        <div className="container pb-5">
          <div className="row">
            <div className="col">
              <div className="text-center mt-5">
                <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                  PRODUCTION FLOWS
                </p>
                <p className="f-size mb-4 fw-medium">How it Works</p>
              </div>
            </div>
          </div>

          <div className="row mt-5">
            <div className="col-md-4 col-sm-12">
              <Work
                title="Get A Free Quote"
                icon={<FaCalculator className="icon" />}
                number="01"
              />
            </div>
            <div className="col-md-4 col-sm-12">
              <Work
                title="Production"
                icon={<IoSettings className="icon" />}
                number="02"
              />
            </div>
            <div className="col-md-4 col-sm-12">
              <Work
                title="Delivery & Assembly"
                icon={<FaPeopleCarryBox className="icon" />}
                number="03"
              />
            </div>
          </div>
          <div className="row mt-5 mb-5">
            <div className="col text-center d-flex gap-2 justify-content-center">
              <button className="btn mm fw-bold rounded-5 px-4 py-3 text-white">
                LEARN MORE
              </button>
              <button className="btn pp fw-bold rounded-5 px-4 py-3 text-white">
                GET A REQUEST
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Our Blogs */}

      <div className="container mt-5 mb-5">
        <div className="row">
          <div className="col">
            <div className="text-center mt-5">
              <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                OUR BLOG
              </p>
              <p className="f-size mb-4 fw-medium">Recent From Blog</p>
            </div>
          </div>
        </div>

        <div className="row mt-5 mb-5 gap-2 justify-content-center">
          <div className="col-6">
            <BlogCard />
          </div>
          <div className="col-6">
            <BlogCard />
          </div>
          <div className="col">
            <BlogCard />
          </div>
          <div className="col">
            <BlogCard />
          </div>
        </div>
      </div>
    </>
  );
}
