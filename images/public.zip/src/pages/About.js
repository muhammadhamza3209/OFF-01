import React from "react";
import Header from "../components/Header";
import img1 from "../assets/about.jpg.webp";
export default function About() {
  return (
    <>
      <div>
        <Header title="About Us" para="ABOUT US" />
      </div>
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <img src={img1} height={680} alt="" />
          </div>
          <div className="col-md-6">
            <div className="p-2 pt-5 mt-5">
              <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                ABOUT FURNISH
              </p>
              <p className="f-size mb-4 lh-sm fw-medium">
                More than 20k Trusted Our Furniture Industry
              </p>
              <p className="text-secondary mb-5 pt-3 mb-0 fs-6">
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts. Separated
                they live in Bookmarksgrove right at the coast of the Semantics,
                a large language ocean.
              </p>
              <p className="text-secondary mb-5 fs-6">
                A small river named Duden flows by their place and supplies it
                with the necessary regelialia. It is a paradisematic country, in
                which roasted parts of sentences fly into your mouth.
              </p>
              <button className="btn mm fw-bold rounded-5 px-4 py-3 text-white">
                LEARN MORE
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Section TOW  2 */}

      <div className="tech-state container-fluid">
        <div className="container pt-5">
          <div className="row">
            <div className="col">
              <div className="text-center mt-5">
                <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                  GREAT REVIEWS FOR OUR SERVICES
                </p>
                <p className="f-size mb-4 lh-sm fw-medium">
                  Technical Statistics
                </p>
              </div>
            </div>
          </div>
          <div className="row text-center mt-5 pb-5">
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-2 mb-0 fw-bold">20</p>
                <p className="fs-6 opacity-50 text-secondary fw-bold">
                  YEAR OF EXPERIENCED
                </p>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-2 mb-0 fw-bold">10,200</p>
                <p className="fs-6 opacity-50 text-secondary fw-bold">
                  SATISFIED CUSTOMERS
                </p>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-2 mb-0 fw-bold">9,850</p>
                <p className="fs-6 opacity-50 text-secondary fw-bold">
                  PROJECT COMPLETED
                </p>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-2 mb-0 fw-bold">20</p>
                <p className="fs-6 opacity-50 text-secondary fw-bold">
                  GET AWARDS
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Happy Customers */}

      <div className="container-fluid body-color pt-5">
        <div className="container">
          <div className="row">
            <div className="col">
              <div className="text-center mt-5">
                <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                  TESTIMONIAL
                </p>
                <p className="f-size mb-4 fw-medium">Happy Customers</p>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col"></div>
          </div>
        </div>
      </div>
    </>
  );
}
