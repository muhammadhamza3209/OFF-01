import React from "react";
import { Route, Routes } from "react-router-dom";
import Footer from "../components/Footer";
import Home from "./Home";
import Collection from "./Collection";
import About from "./About";
import Blog from "./Blog";
import Contact from "./Contact";

export default function Index() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/collection" element={<Collection />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/*" element={<h1>404 Page Not Found </h1>} />
      </Routes>
      <Footer />
    </>
  );
}
