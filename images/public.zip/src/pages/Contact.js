import React from "react";
import Header from "../components/Header";
import CardBus from "../components/CardBus";
import img1 from "../assets/image_1.jpg.webp";
import img2 from "../assets/image_2.jpg.webp";
import img3 from "../assets/image_3.jpg.webp";
import img4 from "../assets/image_4.jpg.webp";
import img5 from "../assets/image_2.jpg.webp";
import img6 from "../assets/image_3.jpg.webp";
export default function Contact() {
  return (
    <>
      <div>
        <Header title="Contact Us" para="CONTACT" />
      </div>
      <div>
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3411.5705353519224!2d73.00063271058754!3d31.232625661196067!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3922f1bc90a69003%3A0x759da00862fbf742!2sFaisalabad%20-%20Samundri%20Rd%2C%20Faisalabad%2C%20Punjab%2C%20Pakistan!5e0!3m2!1sen!2s!4v1720350750738!5m2!1sen!2s"
          width="100%"
          height="450"
          allowfullscreen=""
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>

      <div className="bg-con">
        <div className="container bg-white shadow pt-5">
          <div className="row">
            <div className="col justify-content-center">
              <form>
                <div className="container">
                  <div className="row mb-3">
                    <div className="col">
                      <p className="fs-3 fw-medium">Contact us</p>
                      <p className="text-secondary">
                        We're open for any suggestion or just to have a chat
                      </p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-4">
                      <p className="fw-medium mb-1">ADDRESS:</p>
                      <p className="text-secondary">
                        198 West 21th Street, Suite 721 New York NY 10016
                      </p>
                    </div>
                    <div className="col-md-4">
                      <p className="fw-medium mb-1">EMAIL:</p>
                      <p className="bbb pointer-event">info@yoursite.com</p>
                    </div>
                    <div className="col-md-4">
                      <p className="fw-medium mb-1">PHONE</p>
                      <p className="bbb pointer-event">+ 1235 2355 98</p>
                    </div>
                  </div>
                  <div className="row g-2">
                    <div className="col-md-4 col-sm-12">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Name"
                      />
                    </div>
                    <div className="col-md-4 col-sm-12">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Email"
                      />
                    </div>
                    <div className="col-md-4 col-sm-12">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Subject"
                      />
                    </div>
                    <div className="col mb-4 mt-4">
                      <textarea
                        name=""
                        className="form-control"
                        cols={40}
                        rows={8}
                        placeholder="Create A Name here..."
                        id=""
                      ></textarea>
                      <button className="btn mt-3 mm fw-bold rounded-5 px-4 py-3 text-white">
                        SEND MESSAGE
                      </button>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col">
                      <p className="fs-4 fw-medium">Follow us here</p>
                      <div className="d-flex align-items-center gap-2">
                        <a
                          className="bbb text-decoration-none fw-medium"
                          href="/"
                        >
                          FACEBOOK
                        </a>
                        <a
                          className="bbb text-decoration-none fw-medium"
                          href="/"
                        >
                          TWITTER
                        </a>
                        <a
                          className="bbb text-decoration-none fw-medium"
                          href="/"
                        >
                          INSTAGRAM
                        </a>
                        <a
                          className="bbb text-decoration-none fw-medium"
                          href="/"
                        >
                          DRIBBBLE
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-con">
        <div className="container pt-5 pb-5">
          <div className="row mt-5 pb-5">
            <div className="col pt-5">
              <div className="text-center mt-5">
                <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                  GALLERY
                </p>
                <p className="f-size mb-4 lh-sm fw-medium">Latest Collection</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid mb-0">
        <div className="row g-2 py-2">
          <div className="col-md-2 col-sm-12">
            <CardBus img={img1} />
          </div>
          <div className="col-md-2 col-sm-12">
            <CardBus img={img2} />
          </div>
          <div className="col-md-2 col-sm-12">
            <CardBus img={img3} />
          </div>
          <div className="col-md-2 col-sm-12">
            <CardBus img={img4} />
          </div>
          <div className="col-md-2 col-sm-12">
            <CardBus img={img5} />
          </div>
          <div className="col-md-2 col-sm-12">
            <CardBus img={img6} />
          </div>
        </div>
      </div>
    </>
  );
}
