import React from "react";
import Header from "../components/Header";
import BlogCard from "../components/BlogCard";
import img1 from "../assets/gallery-1.jpg.webp";
import img2 from "../assets/gallery-2.jpg.webp";
import img3 from "../assets/gallery-3.jpg.webp";
import img4 from "../assets/gallery-4.jpg.webp";
import { FaGreaterThan, FaLessThan } from "react-icons/fa";

export default function Blog() {
  return (
    <>
      <div>
        <Header title="Our Blog" para="OUR BLOG" />
      </div>

      <div className="container mt-5 mb-5">
        <div className="row">
          <div className="col">
            <div className="text-center mt-5">
              <p className="text-secondary mb-1 opacity-50 fs-6 fw-bold">
                OUR BLOG
              </p>
              <p className="f-size mb-4 fw-medium">Recent From Blog</p>
            </div>
          </div>
        </div>

        <div className="row mt-5 mb-5 gap-2 justify-content-center">
          <div className="col-md-5 col-12">
            <BlogCard img={img1} />
          </div>
          <div className="col-md-5 col-12">
            <BlogCard img={img2} />
          </div>
          <div className="col-md-5 col-12">
            <BlogCard img={img3} />
          </div>
          <div className="col-md-5 col-12">
            <BlogCard img={img4} />
          </div>
        </div>
        <div className="row mt-4 mb-5 pb-5">
          <div className="col text-center d-flex justify-content-center align-items-center gap-1">
            <button className="btn btn-primary">
              <FaLessThan />
            </button>
            <button className="btn btn-primary">1</button>
            <button className="btn btn-primary">2</button>
            <button className="btn btn-primary">3</button>
            <button className="btn btn-primary">4</button>
            <button className="btn btn-primary">5</button>
            <button className="btn btn-primary">
              <FaGreaterThan />
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
