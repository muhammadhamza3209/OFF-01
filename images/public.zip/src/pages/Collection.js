import React from "react";
import Navbar from "../components/Navbar";
import CardBus from "../components/CardBus";
import img1 from "../assets/gallery-1.jpg.webp";
import img2 from "../assets/gallery-2.jpg.webp";
import img3 from "../assets/gallery-3.jpg.webp";
import img4 from "../assets/gallery-4.jpg.webp";
import img5 from "../assets/gallery-5.jpg.webp";
import img6 from "../assets/gallery-6.jpg.webp";
import img7 from "../assets/image_1.jpg.webp";
import img8 from "../assets/image_4.jpg.webp";
import img9 from "../assets/image_2.jpg.webp";
import { FaGreaterThan } from "react-icons/fa";
import { FaLessThan } from "react-icons/fa";
import Header from "../components/Header";

export default function Collection() {
  return (
    <>
      <div>
        <Header title="Our Collection" para="OUR FINISH PROJECTS" />
      </div>
      <div className="container-fluid mt-5 mb-0">
        <div className="row mt-5 g-2 py-2">
          <div className="col-md-3 col-sm-12">
            <CardBus img={img1} />
          </div>
          <div className="col-md-3 col-sm-12">
            <CardBus img={img2} />
          </div>
          <div className="col-md-6 col-sm-12">
            <CardBus img={img3} />
          </div>
          <div className="col-md-5 col-sm-12">
            <CardBus img={img4} />
          </div>
          <div className="col-md-3 col-sm-12">
            <CardBus img={img5} />
          </div>
          <div className="col-md-4 col-sm-12">
            <CardBus img={img6} />
          </div>
          <div className="col-md-4 col-sm-12">
            <CardBus img={img7} />
          </div>
          <div className="col-md-4 col-sm-12">
            <CardBus img={img8} />
          </div>
          <div className="col-md-4 col-sm-12">
            <CardBus img={img9} />
          </div>
        </div>
        <div className="row mt-4 mb-5 pb-5">
          <div className="col text-center d-flex justify-content-center align-items-center gap-1">
            <button className="btn btn-primary">
              <FaLessThan />
            </button>
            <button className="btn btn-primary">1</button>
            <button className="btn btn-primary">2</button>
            <button className="btn btn-primary">3</button>
            <button className="btn btn-primary">4</button>
            <button className="btn btn-primary">5</button>
            <button className="btn btn-primary">
              <FaGreaterThan />
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
