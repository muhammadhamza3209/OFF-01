import React from "react";
import { FaUser } from "react-icons/fa";
import { FaCalendarAlt } from "react-icons/fa";
import { LuMessageCircle } from "react-icons/lu";

export default function BlogCard(props) {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col">
            <div
              class="card border-0 h-100 body-color mb-3"
              style={{ maxWidth: 600 }}
            >
              <div class="row g-0">
                <div class="col-md-6">
                  <img src={props.img} class="img-fluid h-100 w-100" alt="" />
                </div>
                <div class="col-md-6">
                  <div class="card-body">
                    <div className="d-flex align-items-center mb-0 gap-2">
                      <p className="d-flex align-items-center gap-1">
                        <FaUser className="bbb" /> ADMIN
                      </p>
                      <p className="d-flex align-items-center gap-1">
                        <FaCalendarAlt className="bbb" /> JAN,27,2021
                      </p>
                      <p className="d-flex d-md-none d-lg-block align-items-center gap-1">
                        <LuMessageCircle className="bbb" /> 3
                      </p>
                    </div>
                    <p className="bbb m-0">COMMENTS</p>
                    <h5 class="card-title mt-2">
                      Shop the Look Cottage Country Living Room
                    </h5>
                    <p class="card-text mb-5 mt-3">
                      A small river named Duden flows by their place.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
