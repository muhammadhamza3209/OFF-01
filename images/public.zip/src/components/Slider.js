// src/ImageSlider.js
import React, { useState, useEffect } from "react";

const ImageSlider = ({ slides, interval = 3000 }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const slideInterval = setInterval(() => {
      setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
    }, interval);

    return () => clearInterval(slideInterval);
  }, [slides.length, interval]);

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  return (
    <div className="slider-container">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`slide ${index === currentSlide ? "active" : ""}`}
        >
          <img src={slide.image} alt={slide.text} />
          <div className="slider-text">{slide.text}</div>
        </div>
      ))}
      <div className="slider-buttons">
        {slides.map((_, index) => (
          <button
            key={index}
            className={index === currentSlide ? "active" : ""}
            onClick={() => goToSlide(index)}
          >
            {index + 1}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ImageSlider;

// // src/ImageSlider.js
// import React, { useState, useEffect } from "react";

// const ImageSlider = ({ slides, interval = 3000 }) => {
//   const [currentSlide, setCurrentSlide] = useState(0);

//   useEffect(() => {
//     const slideInterval = setInterval(() => {
//       setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
//     }, interval);

//     return () => clearInterval(slideInterval);
//   }, [slides.length, interval]);

//   const goToSlide = (index) => {
//     setCurrentSlide(index);
//   };

//   const goToPrevSlide = () => {
//     setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
//   };

//   const goToNextSlide = () => {
//     setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
//   };

//   return (
//     <div className="slider-container">
//       {slides.map((slide, index) => (
//         <div
//           key={index}
//           className={`slide ${index === currentSlide ? "active" : ""}`}
//         >
//           <img src={slide.image} alt={slide.text} />
//           <div className="slider-text">{slide.text}</div>
//         </div>
//       ))}
//       <div className="buttons">
//         <button onClick={goToPrevSlide}>Previous</button>
//         {slides.map((_, index) => (
//           <button
//             key={index}
//             className={index === currentSlide ? "active" : ""}
//             onClick={() => goToSlide(index)}
//           >
//             {index + 1}
//           </button>
//         ))}
//         <button onClick={goToNextSlide}>Next</button>
//       </div>
//     </div>
//   );
// };

// export default ImageSlider;
