import React from "react";
import { FaCalendarAlt, FaTwitter, FaUser } from "react-icons/fa";
import { FaFacebookF } from "react-icons/fa6";
import { IoLogoInstagram } from "react-icons/io5";
import { FaLongArrowAltRight } from "react-icons/fa";
import { LuMessageCircle } from "react-icons/lu";
import blog1 from "../assets/image_1.jpg.webp";
import { FaMap } from "react-icons/fa";
import { IoMdCall } from "react-icons/io";
import { FaTelegramPlane } from "react-icons/fa";

export default function Footer() {
  return (
    <>
      <div className="container-fluid tech-state pt-5 pb-5">
        <div className="container pb-5">
          <div className="row pt-3 pb-3">
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-4 fw-medium mt-5 mb-5">Furnish</p>
                <p className="text-black">
                  A small river named Duden flows by their place and supplies it
                  with the necessary regelialia.
                </p>
                <div className="d-flex align-items-center gap-1 mt-4">
                  <button className="btn btn-primary opacity-75">
                    <FaTwitter />
                  </button>
                  <button className="btn btn-primary opacity-75">
                    <FaFacebookF />
                  </button>
                  <button className="btn btn-primary opacity-75">
                    <IoLogoInstagram />
                  </button>
                </div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-4 fw-medium mt-5 mb-5">Services</p>
                <div className="d-flex flex-column gap-3">
                  <a
                    className="d-flex gap-4 text-decoration-none text-secondary"
                    href="/"
                  >
                    <span>
                      <FaLongArrowAltRight />
                    </span>
                    Amazing Deals
                  </a>
                  <a
                    className="d-flex gap-4 text-decoration-none text-secondary"
                    href="/"
                  >
                    <span>
                      <FaLongArrowAltRight />
                    </span>
                    Quality Furniture
                  </a>
                  <a
                    className="d-flex gap-4 text-decoration-none text-secondary"
                    href="/"
                  >
                    <span>
                      <FaLongArrowAltRight />
                    </span>
                    Modern Design
                  </a>
                  <a
                    className="d-flex gap-4 text-decoration-none text-secondary"
                    href="/"
                  >
                    <span>
                      <FaLongArrowAltRight />
                    </span>
                    Best Support
                  </a>
                </div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-4 fw-medium mt-5 mb-5">Recent Posts</p>
                <div className="d-flex gap-4">
                  <div>
                    <img
                      src={blog1}
                      width={60}
                      height={60}
                      className="rounded-2"
                      alt=""
                    />
                  </div>
                  <div className="mb-0">
                    <div className="d-flex align-items-center mb-0  gap-1">
                      <p className="d-flex align-items-center gap-1">
                        <FaUser className="text-primary opacity-75" /> ADMIN
                      </p>
                      <p className="d-flex align-items-center gap-1">
                        <FaCalendarAlt className="text-primary opacity-75" />
                        JAN,27,2021
                      </p>
                      <p className="d-flex d-md-none d-lg-block align-items-center gap-1">
                        <LuMessageCircle className="text-primary opacity-75" />3
                      </p>
                    </div>
                    <p className="fs-6 fw-medium mt-0">
                      Shop the Look Cottage Country Living Room
                    </p>
                  </div>
                </div>
                <div className="d-flex gap-4">
                  <div>
                    <img
                      src={blog1}
                      width={60}
                      height={60}
                      className="rounded-2"
                      alt=""
                    />
                  </div>
                  <div>
                    <div className="d-flex align-items-center mb-0  gap-1">
                      <p className="d-flex align-items-center gap-1">
                        <FaUser className="text-primary opacity-75" /> ADMIN
                      </p>
                      <p className="d-flex align-items-center gap-1">
                        <FaCalendarAlt className="text-primary opacity-75" />{" "}
                        JAN,27,2021
                      </p>
                      <p className="d-flex d-md-none d-lg-block align-items-center gap-1">
                        <LuMessageCircle className="text-primary opacity-75" />3
                      </p>
                    </div>
                    <p className="fs-6 fw-medium mt-0">
                      Shop the Look Cottage Country Living Room
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-12">
              <div>
                <p className="fs-4 fw-medium mt-5 mb-5">Have a Questions?</p>
                <div className="d-flex gap-4">
                  <div>
                    <FaMap className="text-primary opacity-75" />
                  </div>
                  <div>
                    <p>
                      203 Fake St. Mountain View, San Francisco, California, USA
                    </p>
                  </div>
                </div>
                <div className="d-flex gap-4">
                  <div>
                    <IoMdCall className="text-primary opacity-75" />
                  </div>
                  <div>
                    <p>
                      203 Fake St. Mountain View, San Francisco, California, USA
                    </p>
                  </div>
                </div>
                <div className="d-flex gap-4">
                  <div>
                    <FaTelegramPlane className="text-primary opacity-75" />
                  </div>
                  <div>
                    <p>
                      203 Fake St. Mountain View, San Francisco, California, USA
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
