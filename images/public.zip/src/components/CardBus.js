import React from "react";
import { FaSearch } from "react-icons/fa";

export default function CardBus(props) {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col m-0 p-0">
            <div className="first">
              <div>
                <img className="card-img-set" src={props.img} alt="" />
              </div>
              <div className="color"></div>
              <div className="link-A">
                <a className="aa text-white" href="/">
                  <span className="search text-center">
                    <FaSearch className="text-white" />
                  </span>
                  <p className="fs-3 mt-3 fw-medium">
                    Business Finance Consulting
                  </p>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
