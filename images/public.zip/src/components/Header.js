import React from "react";
import Navbar from "./Navbar";

export default function Header(props) {
  return (
    <>
      <div className="m-0 bg-header">
        <div className="black-header"></div>
        <Navbar />
        <div className="container mt-5 pt-5">
          <div className="row mt-5 pt-5">
            <div className="col pt-5">
              <div className="text-center pt-5 mt-5">
                <p className="text-secondary pt-5 mb-1 z-2 opacity-50 fs-6 fw-bold">
                  {props.para}
                </p>
                <p className="f-size mb-4 lh-sm z-2 text-white fw-medium">
                  {props.title}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
