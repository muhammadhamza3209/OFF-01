import React from "react";


export default function Work(props) {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col">
            <div className="text-center">
              <div className="icons shadow mx-auto">
                {props.icon}
                <div className="number">{props.number}</div>
              </div>
              <p className="mb-2 fs-4 pt-4 fw-medium main-color">
                {props.title}
              </p>
              <p className="fs-6 fw-medium text-secondary">
                Far far away, behind the word mountains, far from the countries
                Vokalia.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
