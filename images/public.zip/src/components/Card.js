import React from "react";

export default function Card(props) {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col">
            <div className="w-100">
              <div className="bg-body rounded-circle text-center w-card">
                <span className="fs-1">{props.icon}</span>
              </div>
              <p className="fs-5 fw-medium mt-2 mb-2">{props.title}</p>
              <p className="text-secondary">{props.para}</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
